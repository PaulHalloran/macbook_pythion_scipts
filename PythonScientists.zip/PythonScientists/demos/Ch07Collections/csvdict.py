import csv

FILE="038270-plymouth-ave-temp.txt"

FIELDS = "Year Jan Feb Mar Apr May Jun Jul Aug Sep Oct Nov Dec".split()

with open(FILE) as fp:
    while not "Obs" in fp.readline():
        pass
    jan = 0.0
    reader = csv.DictReader(fp,fieldnames=FIELDS,delimiter=" ",skipinitialspace=True,quoting=csv.QUOTE_NONNUMERIC)
    for (count,row) in enumerate(reader):
        jan += row["Jan"]
    count += 1
    print "%i records, Mean Jan temp = %.3f" % (count,jan/count)