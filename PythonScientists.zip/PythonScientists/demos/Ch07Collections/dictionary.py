capitals = {"UK":"London", "France":"Paris","Germany":"Bonn"}
for country in capitals:
    print country,capitals[country]
capitals["Italy"] = "Rome"
capitals["Germany"] = "Berlin"

if "UK" in capitals:
    del capitals["UK"]

print "Capital of GER is %(Germany)s" % capitals

for country,capital in capitals.items():
    print country,capital

# distance from sun, year
planets = {
   "Mercury":(0.39,88.0),  "Venus":(0.72,224.7),
   "Mars":(1.52,687.0),    "Jupiter":(5.20,4331),
   "Saturn":(9.54,10747),  "Uranus":(19.18,30589),
   "Neptune":(30.06,59800), "Pluto":(39.53,90588)
}

planets["Earth"] = (1,365.2)
if "Pluto" in planets:
    del planets["Pluto"]
for key in sorted(planets):
    print "%-10s %5.2f AU from sun, year %5i days"%(key,planets[key][0],planets[key][1])


def pager(filename,prefs):
    with open(filename) as inp:
        for (i,line) in enumerate(inp):
            if prefs["numbered"]: 
                print "%3i" % (i+1),
            print line,
            if (i+1) % prefs["lines"] == 0: 
                raw_input(prefs["prompt"])

prefs = {"numbered":True, "lines":20, "prompt":"more... "}
prefs = dict(numbered=True, lines=20, prompt="more... ")
pager("caesar.txt",prefs)
