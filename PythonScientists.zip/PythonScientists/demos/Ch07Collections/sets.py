from random import randint

s = set((1,2,3))
s.add(10)
s.add((8,9))
s.remove(2)
print s
fs = frozenset ((1,2,3))

ticket = set()
while len(ticket) < 6:
    ticket.add(randint(1,49))
print " ".join([str(t) for t in ticket])


inner = set(("Mercury","Venus","Earth"))
outer = set(("Earth","Mars","Jupiter","Saturn","Uranus","Neptune","Pluto"))
if "Pluto" in outer:
    outer.remove("Pluto")

all = inner | outer 
print all
print "In both sets:"," ".join([p for p in inner & outer])
print "In either set but not both:"," ".join([p for p in inner ^ outer])
