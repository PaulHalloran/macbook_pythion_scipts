from random import randint
limit = 10000
scale = 5
freq = {}

for i in range(1,limit):
    n = randint(1,49)
    if n in freq:
        freq[n] = freq[n]+1
    else:
        freq[n] = 1

for key in freq:
    print "%2i:%s" % (key,"*"*(freq[key]/scale))
