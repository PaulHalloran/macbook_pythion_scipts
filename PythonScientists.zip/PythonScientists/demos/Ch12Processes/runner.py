import random, sys
import subprocess as sp

def main(log):
    children = []
    
    for n,x in enumerate(range(random.randint(1,5))):
        children.append(sp.Popen([r"python2.7","saver.py",str(n)], 
                                 stdin=sp.PIPE, stdout=log, stderr=log))
    
    for c in children:
        for n in range(random.randrange(100)):
            c.stdin.write("data line %.6f\n" % random.random())
        c.stdin.close()
    
    errs = []
    for c in children:
        status = c.wait()
        if status:
            errs.append("child %i failed %i" % (c.pid,status))
    if errs:
        raise UserWarning("\n".join(errs))
    
if __name__ == '__main__':
    try:
        with open("runner.log","w") as log:
            main(log)  
        print "Job done"                             
        sys.exit(0)
    except Exception as ex:
        print >>sys.stderr,"ERROR: %s" % ex
        sys.exit(1)        