'''
dummy mail program
'''
import sys
for line in sys.stdin:
    pass

