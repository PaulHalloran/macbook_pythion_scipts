from subprocess import Popen, PIPE
import sys

if len(sys.argv)!=4:
    print >>sys.stderr, "Usage: mailer recipient subject message"
    sys.exit(1)
    
cmd = ["mail","-s",sys.argv[2],sys.argv[1]]
p = None
try:
    p = Popen(cmd, stdin=PIPE)
    p.stdin.write(sys.argv[3])
    p.stdin.write("\n")
except OSError as ex:
    print >>sys.stderr, "Mailer failed to execute:", ex
    sys.exit(2)
finally:
    if p:
        p.stdin.close()
        retcode = p.wait()
        if retcode != 0:
            print >>sys.stderr, "Mailer returned error code "+retcode
            sys.exit(2)
