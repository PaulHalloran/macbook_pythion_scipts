from subprocess import Popen, PIPE

cmd = ["netstat","-an"]
try:
    p = Popen(cmd, stdout=PIPE, stderr=PIPE)
    (stdout,stderr) = p.communicate()
    if p.wait() != 0:
        raise UserWarning("Child command failed code="+str(p.wait()))
        
    if stdout:
        for line in stdout.split("\n"):
            if "TCP" in line or "STREAM" in line: print line,
    if stderr:
        for err in stderr.split("\n"):
            print "ERR:",err,
            
except OSError as ex:
    raise UserWarning("Command execution failed:"+str(ex))
