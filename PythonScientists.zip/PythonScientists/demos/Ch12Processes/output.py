from subprocess import Popen, PIPE

cmd = ["netstat","-an"]
try:
    p = Popen(cmd, stdout=PIPE, stderr=PIPE)
    
    for line in p.stdout:
        if "TCP" in line or "STREAM" in line: print line,

    for err in p.stderr:
        print "ERR:",err,

    p.stderr.close()
    p.stdout.close()
    retcode = p.wait()
    if retcode != 0:
        raise UserWarning("Child command failed code="+str(retcode))
            
except OSError as ex:
    raise UserWarning("Command execution failed:"+str(ex))

