import sys

def main(name):
    with open("file" + name, "w") as fp:
        fp.write("worker %s\n" % name)
        for line in sys.stdin:
            fp.write(line)

if __name__ == '__main__':
    name = sys.argv[1]
    try:
        print >>sys.stderr,"START worker %s" % (name,)
        main(name)
        print >>sys.stderr,"END worker %s" % (name,)
        sys.exit(0)
    except Exception as ex:
        print >>sys.stderr,"ERROR worker %s: %s" % (name,ex)
        sys.exit(1)