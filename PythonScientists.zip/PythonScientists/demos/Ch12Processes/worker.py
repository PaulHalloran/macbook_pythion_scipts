'''
simulate workload
'''
import os, sys, time

delay = 2

if len(sys.argv) > 1:
    try:
        delay = int(sys.argv[1])
    except:
        print "Invalid worker delay",sys.argv[1]

print "Worker %s delay %i"%(os.getpid(),delay)
time.sleep(delay)
print "Worker %s done"%(os.getpid(),)
       
