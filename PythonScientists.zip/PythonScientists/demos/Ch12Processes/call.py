import sys, subprocess
    
cmd = "python -V"

try:
    retcode = subprocess.call(cmd, shell=True)
    if retcode < 0:
        print "Child was terminated by signal", -retcode
    elif retcode:
        print "Child returned", retcode
except OSError as ex:
    print >>sys.stderr, "Execution failed:", ex

worker = ["python2.7","worker.py"]
try:
    p1 = subprocess.Popen(worker+["1"])
    p2 = subprocess.Popen(worker+["3"])
    p3 = subprocess.Popen(worker+["4"])
    for proc in (p1,p2,p3):
        s = proc.wait()
        print "Process %i returned %i"%(proc.pid,s)
except OSError as ex:
    print >>sys.stderr, "Worker execution failed:", ex
    