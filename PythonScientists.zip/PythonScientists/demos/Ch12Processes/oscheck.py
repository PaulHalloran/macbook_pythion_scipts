import os, platform

print "Host os is",os.sys.platform

if os.sys.platform == "win32":
    cmd = "cmd /c dir"
elif os.sys.platform == "darwin":
    cmd = "ls -l"
elif os.sys.platform == "linux2":
    cmd = "ls -l"
else:
    cmd = "uname -s; uname -r"
    
os.system(cmd)

(major, minor, patchlevel) = platform.python_version_tuple()
print "Python",[major, minor, patchlevel]
(system, node, release, version, machine, processor) = platform.uname()
print "Uname",[system, node, release, version, machine, processor]