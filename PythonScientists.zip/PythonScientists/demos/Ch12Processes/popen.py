from subprocess import Popen, PIPE
import sys

if sys.platform == "win32":
    cmd = ["cmd","/c","dir"]
else:
    cmd = ["ls","-l"]

try:
    p = Popen(cmd, stdout=PIPE, stderr=PIPE)
    
    for err in p.stderr:
        print "ERR:",err,
    
    for line in p.stdout:
        print line,
    
except OSError as ex:
    print >>sys.stderr, "Execution failed:", ex
finally:
    if p:
        retcode = p.wait()
        if retcode < 0:
            print >>sys.stderr, "Child was terminated by signal", -retcode
        elif retcode:
            print >>sys.stderr, "Child returned", retcode
