def fibonacci(n) :
    list = (0,1)
    while len(list) < n:
        list += (list[-2]+list[-1],)
    return list

try:
    limit = raw_input("Print Fibonacci series for how many terms? ")
    print fibonacci(int(limit))
except EOFError:
    print "Request cancelled"
    
