def fibonacci(n) :
    lst = [0,1]
    while len(lst) < n:
        lst.append(lst[-2]+lst[-1])
    return lst
limit = raw_input("Print Fibonacci series for how many terms? ")
print fibonacci(int(limit))
