def fibonacci(n) :
    list = (0,1)
    while len(list) < n:
        list += (list[-2]+list[-1],)
    return list

def read_range (prompt, low=0, high=100):
    n = int(raw_input(prompt))
    if n<low or n>high :
        raise UserWarning("Number must be between %i and %i" % (low,high))
    return n
    
try:
    limit = read_range("Print Fibonacci series for how many terms? ",2,20)
    print fibonacci(limit)
except (EOFError,ValueError):
    print "Please enter an integer value"
except UserWarning as cause:
    print cause
    
