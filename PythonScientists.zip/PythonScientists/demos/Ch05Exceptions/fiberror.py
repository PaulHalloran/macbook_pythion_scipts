fib = (0,1,1,2,3,5,8,13,21,34)

i=0
while True:
    print fib[i],
    i += 1
    
     