
source = r"caesar.txt"

try:
    with open(source,"r") as inp:
        for line in inp: 
            print line,
except IOError as cause:
    print "I/O problem:",cause