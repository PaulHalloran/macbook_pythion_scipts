   
class FibError(Exception):
    pass

def fibonacci(n) :
    list = (0,1)
    while len(list) < n:
        list += (list[-2]+list[-1],)
    return list

def read_range (prompt, low=0, high=100):
    try :
        n = int(raw_input(prompt))
        if n<low or n>high :
            raise FibError("Number must be between %i and %i" % (low,high))
        return n
    except (EOFError,ValueError):
        raise FibError("Number must be an integer value")

try:
    limit = read_range("Print Fibonacci series for how many terms? ",2,20)
    print fibonacci(limit)
except FibError as ex:
    print ex
