import sys
import numpy as np
import metdata as mt
import matplotlib.pyplot as plt

FILE = "038270-plymouth-ave-temp.txt"

try:
    temps = mt.AvgTemp(FILE)
    avgs_year = temps.avgdata().mean(axis=1)
    avg = avgs_year.mean()
    diffs = avgs_year-avg

    x = temps.year_range()
    y = np.zeros(len(x))
    bars = [-np.minimum(y,diffs),np.maximum(y,diffs)]
    ax = plt.figure().add_subplot(111)
    ax.errorbar(x,y,yerr=bars,ecolor="#000044",label="_nolegend_")
    ax.plot(x,temps.moving_avg()-avg,color="red",linewidth=2,label="10 year rolling avg")
    ax.annotate('Dec 1878 & Jan 1879\nmean temp below 0C for two consecutive months', 
                xy=(1879,-1.5), xytext=(10,15), textcoords='offset points',
                arrowprops=dict(arrowstyle="->", color='black', linewidth=2))
    limit = max(-diffs.min(),diffs.max())
    ax.set_ylim(limit*-1.1,limit*1.1)
    ax.set_xlabel('Year')
    ax.set_ylabel('Mean Temperature Anomaly')
    ax.legend()
    plt.title("Mean Temperature Annual Anomalies")
    plt.show()
    #plt.savefig("avg_anomalies.png")

except mt.MetdataError as ex:
    print >>sys.stderr,ex
    sys.exit(1)
    







