import sys
import calendar
import metdata as mt
import matplotlib.pyplot as plt

FILE = "038270-plymouth-ave-temp.txt"
    
try:
    temps = mt.AvgTemp(FILE)
    tavg = temps.avgdata().mean(axis=0)
    tmin = temps.avgdata().min(axis=0)
    tmax = temps.avgdata().max(axis=0)

    y = tavg
    x = range(1,len(y)+1)
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.errorbar(x,y,yerr=[y-tmin,tmax-y],ecolor="#000044",capsize=2)
    ax.set_xlabel('Month')
    ax.set_ylabel('Average Temperature')
    ax.grid(True)
    plt.xlim(0,len(x)+1)
    plt.ylim(min(0,tmin.min()-1),max(20,tmax.max()+1))
    plt.xticks(x, calendar.month_abbr[1:13],rotation=66)
    fig.subplots_adjust(bottom=0.15)
    plt.show()

except mt.MetdataError as ex:
    print >>sys.stderr,ex
    sys.exit(1)
    