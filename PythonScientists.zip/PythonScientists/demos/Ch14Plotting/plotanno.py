import sys
import numpy as np
import metdata as mt
import matplotlib.pyplot as plt

FILE = "038270-plymouth-ave-temp.txt"
        
try:
    temps = mt.AvgTemp(FILE)
    avgs_year = temps.avgdata().mean(axis=1)
    avg = avgs_year.mean()
    diffs = avgs_year-avg

    x = temps.year_range()
    y = np.zeros(len(x))
    bars = [-np.minimum(y,diffs),np.maximum(y,diffs)]
    ax = plt.figure().add_subplot(111)
    ax.errorbar(x,y,yerr=bars,ecolor="#000044")
    ax.set_xlabel('Year')
    ax.set_ylabel('Mean Temperature Anomaly')
    limit = max(-diffs.min(),diffs.max())
    ax.set_ylim(limit*-1.1,limit*1.1)
    ax.text(0.5, 0.9, 'Line shows average temperature $^O$C,\nBars show min/max average temperature.',
            horizontalalignment="center", transform=ax.transAxes)
    ax.annotate('Dec 1878 & Jan 1879\nmean temp below 0C for two consecutive months', 
                xy=(1879,-1.5), xytext=(10,15), textcoords='offset points',
                arrowprops=dict(arrowstyle="->", color='black', linewidth=2))
    plt.title("Mean Temperature Annual Anomalies")
    plt.show()

except KeyError as ex:
    print >>sys.stderr,"No data for year",ex
    sys.exit(1)
    







