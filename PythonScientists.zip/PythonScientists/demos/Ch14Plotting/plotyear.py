import sys
import calendar
import metdata as mt
import matplotlib.pyplot as plt

FILE = "038270-plymouth-ave-temp.txt"

def plot_year(year):
    temps = mt.AvgTemp(FILE)
    y = temps.year(year)
    x = range(1,len(y)+1)
    fig = plt.figure()
    ax = fig.add_subplot(111)
    ax.plot(x,y,color="blue")
    ax.set_xlabel("Monthly Average Temp for %i"%year)
    ax.set_ylabel(r"Temperature $^o$C")
    ax.grid(True)
    plt.xlim(1,len(x))
    plt.xticks(x, calendar.month_abbr[1:13], rotation=66)
    fig.subplots_adjust(bottom=0.15)
    plt.show()
    
try:
    plot_year(2000)

except mt.MetdataError as ex:
    print >>sys.stderr,ex
    sys.exit(1)

    




