import numpy as np
import matplotlib.pyplot as plt
import pdb

plt.ion()
pdb.set_trace()
x = np.linspace(-2.0,2.0,40)
plt.figure()
plt.plot(x,x**2,'b-', linewidth=2)
plt.plot(x,(x*2)**2,'r--', linewidth=2)
plt.plot(x,(x*3)**2,'k-.o', linewidth=2)
plt.plot(x,(x*4)**2,'y:^', linewidth=2)
plt.plot(x,(x*5)**2, linestyle='r:s', linewidth=2)
plt.legend(loc="upper center")
plt.xlim(-2.0,2.0)
plt.ylim(0.0,40.0)
plt.title("Line styles")