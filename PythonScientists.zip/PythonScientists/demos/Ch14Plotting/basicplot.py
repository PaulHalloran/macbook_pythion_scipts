import numpy as np
import matplotlib.pyplot as plt

x = np.linspace(0.0,2.0,20)
y = np.exp(x)
plt.plot(x,y)
plt.show()

x = np.linspace(0.0,2.0,20)
fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(x,np.exp(x))
plt.show()

x = np.linspace(0.0,2.0,20)
fig = plt.figure()
ax = fig.add_subplot(311)
ax.plot(x,x)
bx = fig.add_subplot(312)
bx.plot(x,np.log(x))
cx = fig.add_subplot(313)
cx.plot(x,x**2)
plt.show()

x = np.linspace(0.0,2.0,20)
fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(x,np.log(x))
ax.plot(x,x**2)
plt.show()

x = np.linspace(0.0,2.0,20)
fig = plt.figure()
ax = fig.add_subplot(111)
ax.plot(x,np.log(x),color="blue")
ax.set_ylabel(r'log(x)',color="blue");
bx = ax.twinx()
bx.plot(x,x**2,color="green")
bx.set_ylabel(r'x**2',color="green");
plt.show()

x = np.linspace(-2.0,2.0,40)
ax = plt.figure().add_subplot(111)
ax.plot(x,x**2,'b--',label=r'$x^2$')
ax.plot(x,2**x,label=r'$2^x$',color="#008822", linestyle=":", marker='d')
ax.grid(True)
ax.set_xlim(-2.0,2.0)
ax.legend(loc="upper center")
plt.title("Custom plotting")
plt.show()

x = np.linspace(-2.0,2.0,40)
ax = plt.figure().add_subplot(111)
ax.plot(x,x**2,'b-', linewidth=2)
ax.plot(x,(x*2)**2,'r--', linewidth=2)
ax.plot(x,(x*3)**2,'k-.o', linewidth=2)
ax.plot(x,(x*4)**2,'y:^', linewidth=2)
ax.plot(x,(x*5)**2, linestyle='r:s', linewidth=2)
ax.set_xlim(-2.0,2.0)
ax.set_ylim(0.0,40.0)
plt.title("Line styles")
plt.show()








