class Person:
    pass

mb = Person()
mb.name = "Martin"
mb.skills = ["Python", "Java", "Perl", "Linux"]
print "%s knows %s"%(mb.name,mb.skills)

class Person:
    name = "Anonymous"
    skills = []
    def iam(self, name):
        self.name = name
        
    def whoami(self):
        return self.name
    
mb = Person()
mb.iam("Martin")
print mb.whoami()

class Person:
    '''defines a person'''
    def __init__(self,name,skills=[]):
        self.name = name
        self.skills = skills      
    def whoami(self):
        return self.name
      
mb = Person("Martin")
print mb.whoami()

class Person:
    def __init__(self,name,skills=[]):
        self.name = name
        self.skills = skills      
    def __str__(self):
        return "%s knows %s"%(self.name,self.skills)
      
mb = Person("Martin", ["Python", "Java", "Perl", "Linux"])
print mb
message = str(mb)+"\n"

class Person:
    def __init__(self,name,skills=[]):
        self.name = name
        self.skills = skills      
    def __str__(self):
        return "%s knows %s"%(self.name,self.skills)
    __repr__ = __str__

people = [
    Person("Martin", ["Python", "Java", "Perl", "Linux"]),
    Person("Guido", ["Python", "ABC"]),
] 
print people
