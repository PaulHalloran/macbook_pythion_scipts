class Bag:
    def __init__(self,goods=[]):
        self.goods = {}
        for key in goods:
            self += key
    def __str__(self):
        return "Bag: "+str(self.goods)
    def __len__(self):
        return sum(self.goods.values())
    def __iadd__(self,rhs):
        if rhs in self.goods:
            self.goods[rhs] += 1
        else:
            self.goods[rhs] = 1
        return self
    def __add__(self,rhs):
        new = Bag()
        for key,value in self.goods.items():
            new.goods[key] = value
        new += rhs
        return new
    def __contains__(self,rhs):
        return rhs in self.goods
    def __eq__(self,rhs):
        return self.goods == rhs.goods
    def __ne__(self,rhs):
        return self.goods != rhs.goods
    
    def __getitem__(self,index):
        return self.goods[index]
    def __setitem__(self,index,value):
        self.goods[index] = value
        
    count = 0
    def __iter__(self):
        self.count = 0
        return self
    def next(self):
        if self.count>=len(self.goods):
            raise StopIteration()
        key = self.goods.keys()[self.count]
        self.count += 1
        return (key,self.goods[key])
    
shopping = Bag(["apples","pears","oranges"])
shopping += "oranges"
print shopping    
bought = shopping + "chocolate"
print "we bought %i items: %s" % (len(bought),bought)
if shopping != bought:
    print "we didn't buy the right stuff"
if not "bananas" in bought:
    print "we forgot to buy bananas"

shopping["lemons"] = 3    
print "we need",shopping["lemons"],"lemons"

for (name,count) in bought:
    print "we bought %i %s" % (count,name)
