import numpy as np

data2d = np.array([[1,2],[3,4],[4,5],[6,7]])
prod = np.array([10,11])
print "increment", data2d+1
print "product", data2d*prod

mat = np.matrix('1 2; 3 4; 5 6; 7 8')
matprod = np.matrix([[1,2,3],[3,4,5]]) 
print "increment", mat+1
print "product", mat * matprod