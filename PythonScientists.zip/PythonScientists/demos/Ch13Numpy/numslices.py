import numpy as np

data2d = np.random.normal(size=(10,5))
print "Random normal distribution",data2d

print "first element",data2d[0,0]
print "last row",data2d[-1]
print "column 3", data2d[:,3]
print "columns 2 & 4",data2d[:,(2,4)]

col_avg = data2d.mean(axis=0)
print "Column average",col_avg
print "above average columns",data2d[:,col_avg>=0.0]

cols = []
for c in range(len(data2d[0])):
    ave = 0.0
    for r in range(len(data2d[:,c])):
        ave += data2d[r,c]
    ave /= len(data2d[:,c])
    if ave >= 0.0:
        cols.append(c)
found = []
for r in range(len(data2d[0])):   
    row = []
    for c in cols:
        row.append(data2d[r,c])
    found.append(row)
print "found",found
    
