import numpy as np

data = np.arange(0,10,dtype=np.float)
print "range array",data

points = np.linspace(-1.0,1.0,8,endpoint=False)
print "points array",points

ident = np.identity(4)
print "identity",ident

zero = np.zeros([2,5],dtype=np.int)
print "zeros",zero

ones = np.ones([2,5],dtype=np.int)
print "zeros",zero

blank = np.empty(3)
print "unitialised",blank





