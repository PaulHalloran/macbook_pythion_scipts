import numpy as np
import numpy.random as npr

numbers = np.random.random(5)
print "random",numbers

numbers = npr.randn(2,5)
print "standard normal",numbers

numbers = npr.normal(50,0.1,(2,5))
print "normal about 50",numbers

numbers = npr.poisson(50,[2,10])
print "poisson about 50",numbers
