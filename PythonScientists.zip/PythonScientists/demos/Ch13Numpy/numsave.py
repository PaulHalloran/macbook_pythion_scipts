import os
import numpy as np

FILENAME = "sample.npy" # "sample.npz"
       
if not os.path.exists(FILENAME):
    data = np.random.randn(10)
    np.save(FILENAME,data)
    print "saved",data
else:
    data = np.load(FILENAME)
    print "restored",data
    os.remove(FILENAME)
    




