import numpy as np

blank = np.empty((4,4))
blank.fill(np.NAN)
print "filled nan",blank

vector = np.arange(24)
data2d = np.reshape(vector,[3,8])
print "data2d from vector",data2d
vector[1] = -99
print "updated data",data2d[0]

data = np.array([0,1,1,2,3,5,8,13,21,34])
print "squared",data*data
print "doubled",data*2

data += 1
print "incremented",data

data2d = np.arange(1,13).reshape([3,4])
data2d *= np.array([2,3,4,5])
print "multiplied data2d",data2d

data2d = np.array([[1,2,3,4],[2,3,4,5],[3,4,5,6]])
print "2d data",data2d
print "all cells avg",data2d.mean()
print "row min",data2d.min(axis=1)
print "col max",data2d.max(axis=0)
print "row sum",data2d.sum(axis=1)
