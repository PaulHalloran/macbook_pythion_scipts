import numpy as np

data = np.arange(10)
print "data",data
print "start",data[0],"end",data[-1]

data[-1] = data [0]
print "updated",data

rand = np.random.random([4,3,2])
print "first random",rand[0,0,0]
print "last row random",rand[-1,-1]

data2d = np.array([[1,2,3,4],[5,6,7,8],[9,10,11,12]])
cols = data2d[1:3] 
data2d[2] = [21,22,23,24]
cols[0] = [15,16,17,18]
print "updated original",data2d
print "updated copy",cols

data = np.array([range(1,11),range(11,21),range(21,31),range(31,41),range(41,51)])
print "Big table",data
steps = data[::2,::3]
print "Small table",steps



