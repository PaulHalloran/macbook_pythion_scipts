import numpy as np

class AvgTemp:
    '''
    Example class to read average yearly temperature data from
    sample data file with headers ending with line "Obs:"
    Each data row in file is year followed by 12 average 
    temperature readings, -99.0 in dataset is mapped to NAN
    Attributes:
      first - first year in dataset
      last  - last year in dataset
      temps - numpy array of temperatures shape (num_years,12)
    '''
    def __init__(self, filename):
        '''
        Read temperature data from file:
          filename - name of source file
        '''
        self.first = None
        self.last = None
        with open(filename) as fp:
            temps = self.read(fp)
            self.temps = self.read(fp,temps)

    def __str__(self):
        return "years %i..%i:\n%s" % (self.first,self.last,self.temps)

    COLS=13
    MASK=-99.0
    def read(self,fp,temps=None):
        '''
        Helper function reread open data file.
        Call with temps not set to create empty numpy array,
        call again passing in array from first call to fill in the data.
          fp    - open file pointer
          temps - None to create empty array, or array to store values
        '''
        fp.seek(0)
        for line in fp:
            if line.startswith("Obs"):
                break
        for index,line in enumerate(fp):
            data = line.split()
            if len(data) != AvgTemp.COLS:
                raise IOError("Badly formated data at line %s"%line)
            if temps != None:
                row = np.array(data[1:],dtype=np.float)
                row[row==AvgTemp.MASK] = np.NAN
                temps[index] = row
                if not self.first:
                    self.first = int(data[0])
                self.last = int(data[0])
        return temps if temps!=None \
                     else np.empty((index+1,AvgTemp.COLS-1),dtype=np.float)

if __name__ == '__main__':
    data = AvgTemp("038270-plymouth-ave-temp.txt")
    print data