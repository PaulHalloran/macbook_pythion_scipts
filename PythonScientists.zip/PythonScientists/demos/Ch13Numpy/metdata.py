import numpy as np

class MetdataError(Exception):
    pass

class avgtemp:
    def __init__(self, filename):
        self.years = []
        temps = []
        with open(filename) as ifp:
            for line in ifp:
                if line.startswith("Obs"):
                    break
            for line in ifp:
                if line.find("-99.0") != -1:
                    continue
                data = line.split()
                if len(data) != 13:
                    continue
                self.years.append(int(data[0]))
                temps.append(np.array(data,dtype=np.float))
        self.temps = np.array(temps)

    def year_range(self):
        "return list of years for temperature data"
        return self.years
    
    def year(self,year):
        "return average temp arrays for given year"
        if not year in self.years:
            raise MetdataError("No data for year %i"%year)
        return self.temps[self.years.index(year)][1:]
    
    def month(self,month):
        "return all years data for given month"
        if month < 1 or month > 12:
            raise MetdataError("Invalid month %i, must be between 1 and 12"%month)
        return self.temps[:,month]

    def avgdata(self):
        "return raw temperature data, month index from 0"
        return self.temps[:,1:]
 
    def mins(self):
        "return minimum average temperatures"
        return self.avgdata().min(axis=0)
                    
    def min_month(self,month):
        "return list of years for given month and temperature"
        avgs = self.avgdata()
        mins = avgs.min(axis=0)
        return (np.array(self.years)[avgs[:,month]==mins[month]],mins[month])

    def moving_avg(self,window=10):
        avgs = self.avgdata()
        year_means = avgs.mean(axis=1)
        means = np.empty(len(year_means))
        for r in xrange(len(year_means)):
            means[r] = avgs[max(0,r-window):r+1].mean()
        return means
       
    def moving_avg_index(self,window=10):
        avgs = self.avgdata()
        year_means = avgs.mean(axis=1)
        rows = []
        for r in xrange(len(year_means)):
            rows.append(np.arange(max(0,r-window),r+1))
        rollup = np.empty(len(rows))
        for i,row in enumerate(rows):
            rollup[i] = avgs[row].mean()
        return rollup
    

