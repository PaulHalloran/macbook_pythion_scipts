import numpy as np
import numpy.ma as ma

data = np.array([[1,2,3,4],[5,6,7,8],[9,10,11,12]])
data[:,1] = data[0,0] = data[2,3] = -99
print "data", data
clean = ma.masked_values(data, -99)
print "shape %s\ndata %s" % (clean.shape,clean)

print "mean value =",clean.mean()
print "col average =",clean.mean(axis=0)
print "col filled avg =",clean.sum(axis=0).filled(0)
print "sqrt =",ma.sqrt(clean)

data = np.array([[1,2,3,4],[5,6,7,8],[9,10,11,12]])
view = ma.masked_outside(data,4,9)
view[:,1] = ma.masked
view *= 10
print "view =",view

v9 = view + 9
v9[0,1] = 99
print "v9 =",v9

print "data =",v9.data
print "mask =",v9.mask
data2 = np.arange(1,13).reshape((3,4))
match = ma.array(data2,mask=v9.mask)
print "match",match

print "same data =",id(v9.data)==id(view.data)



