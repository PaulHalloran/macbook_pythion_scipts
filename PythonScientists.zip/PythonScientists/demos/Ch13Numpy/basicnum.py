import numpy as np

data = np.array([0,1,1,2,3,5,8,13,21,34])
print "numpy 1D array",data

data2d = np.array([[1,3,5],[2,4,6],[9,8,7]])
print "2D array",data2d

data3d = np.array([[[1,2,3,4],[2,3,4,5],[3,4,5,6]],[[4,5,6,7],[5,6,7,8],[6,7,8,9]]])
print "3D array",data3d
print "Shape =",data3d.shape

fdata = np.array([1,2,3,4,5,6],dtype=np.float)
print "numpy float array",fdata

data3 = np.array([[data,[0,1,2,6,24,120,]],[[0,1,2]]])
print "object list",data3
