import numpy as np

data2d = np.array([[1,2],[3,4],[5,6],[7,8]])
indexes = [1,3]
print "data2d columns", data2d[indexes]

data2d[1:3] = [[9,10],[11,12]]
cols = data2d[[1,2]]
cols[1] = [0,0]
print "updated original", data2d
print "updated copy", cols
