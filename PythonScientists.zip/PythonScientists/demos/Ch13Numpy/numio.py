import numpy as np

infile = "038270-plymouth-ave-temp.txt"
    
data = np.genfromtxt(infile, skip_header=21, usecols=range(1,13))
for year in data:
    print "".join("%6.2f"%month for month in year)
    
    




