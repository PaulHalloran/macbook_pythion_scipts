import numpy as np
import numpy.ma as ma

class AvgTemp:
    COLS=13
    MASK=-99.0
    START="Start year"
    END="End year"
    def __init__(self, filename):
        with open(filename) as fp:
            line = ""
            while not line.startswith("Obs"):
                line = fp.readline()
                meta = line.split("=")
                key = meta[0].strip()
                if key == AvgTemp.START:
                    self.first = int(meta[1])
                elif key == AvgTemp.END:
                    self.last = int(meta[1])
            shape = (self.last-self.first+1,AvgTemp.COLS-1)
            temps = np.empty(shape,dtype=np.float)
            for index,line in enumerate(fp):
                data = line.split()
                if len(data) != AvgTemp.COLS:
                    raise IOError("Badly formated data at line %s"%line)
                row = np.array(data[1:],dtype=np.float)
                temps[index] = row
            self.temps = ma.masked_values(temps,AvgTemp.MASK)
            
    def __str__(self):
        return "years %i..%i:\n%s" % (self.first,self.last,self.temps)

if __name__ == '__main__':
    data = AvgTemp("038270-plymouth-ave-temp.txt")
    print data