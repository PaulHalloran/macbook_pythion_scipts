import sys
import calendar
import numpy as np
import metdata as mt

infile = "038270-plymouth-ave-temp.txt"

try:
    temps = mt.avgtemp(infile)

    print "Average monthly temps for 1990",temps.year(1990)
    
    print "Average July temp for all years",temps.month(7).mean()

    avgs = temps.avgdata().mean(axis=0)
    print "Average temperatures for all years",avgs
   
    print "All time average minimums",temps.mins()
    
    avgs_year = temps.avgdata().mean(axis=1)
    print "Yearly average temperatures",avgs_year
    avg = avgs_year.mean()
    print "Average annual temp",avg
    print "Differences from annual average",avgs_year-avg

    month = 3
    (found,temp) = temps.min_month(month)
    print "%s min temp %.2f in years %s"%(calendar.month_name[month],temp,found)
       
    print "Yearly moving averages",temps.moving_avg()
    
   
except mt.MetdataError as ex:
    print >>sys.stderr,ex
    sys.exit(1)

    




