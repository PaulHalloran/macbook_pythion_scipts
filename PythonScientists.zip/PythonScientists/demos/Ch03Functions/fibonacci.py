def fibonacci(n) :
    list = []
    while len(list) < n:
        if (not list):
            list = [0]
        elif (len(list) == 1):
            list.append(1)
        else:
            list.append(list[-2]+list[-1])
    return list

print fibonacci(20)

