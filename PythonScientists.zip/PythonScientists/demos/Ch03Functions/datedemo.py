from datetime import datetime as dt
today = dt.today()
print today

now = dt.now()
print now

print now.strftime("%a, %d-%b-%Y %H:%M")

olympics = dt.strptime("20120727193000","%Y%m%d%H%M%S")
print olympics.strftime("%a, %d-%b-%Y %H:%M")

def label(n,single,plural):
    return str(n)+" "+(single if n==1 else plural)

delta = olympics-today if today<olympics else today-olympics 
 
print label(delta.days,"days","days"),\
      label(delta.seconds/(60*60),"hour","hours"),\
      label(delta.seconds/60%60,"min","mins")

import time, random
print "Press enter when prompted..."
time.sleep(random.randint(3,5))
start = time.clock()
ans = raw_input("?")
end = time.clock()
print "you took",end-start,"seconds to respond"