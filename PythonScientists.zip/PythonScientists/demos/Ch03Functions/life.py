import os
from copy import deepcopy

DIM = 40
INIT = ((3,3),(2,3),(4,3),
        (8,3),(8,4),(8,5),(7,5),(6,4))

EMPTY='.'
LIFE='X'

def new():
    pond = [ ]
    for n in range(0,DIM):
        row = []
        for m in range(0,DIM):
            row.append(EMPTY)
        pond.append(row)
    return pond

def show(title,pond):
    print title
    for row in pond:
        print "".join(row)
    print

def lives(pond,r,c):
    neighbours = 0
    for row in range(r-1,r+2):
        for col in range(c-1,c+2):
            if row==r and col==c: continue
            if pond[row][col]==LIFE: 
                neighbours+=1
    return neighbours

def seed(pond, cells):
    for cell in cells:
        pond[cell[0]][cell[1]] = LIFE

def generate(pond):
    breed = new()
    for row in range(1,DIM-1):
        for col in range(1,DIM-1):
            n = lives(pond,row,col)
            if (pond[row][col]==LIFE and n in (2,3)) or (pond[row][col]==EMPTY and n==3):
                breed[row][col] = LIFE
    return breed

pond = new()
seed(pond,INIT)
count = 0
while True:
    os.system("cls")
    show("Generation "+str(count),pond)
    more = raw_input("Stop [y]? ")
    if  more.strip().lower().startswith("y"): break
    pond = generate(pond)
    count = count + 1

