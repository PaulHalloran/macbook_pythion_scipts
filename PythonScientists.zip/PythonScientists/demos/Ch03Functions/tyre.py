def tyre():
    def inner():
        print "inner-tyre",
    inner()
    print "tyre"

def tube():
    def inner():
        print "inner-tube",
    inner()
    print "tube"

tyre()
tube()

def silly(n):
    if (n%2==0) :
        def show():
            print 'even'
    else:
        def show():
            print 'odd'
    show()
silly(1)
    