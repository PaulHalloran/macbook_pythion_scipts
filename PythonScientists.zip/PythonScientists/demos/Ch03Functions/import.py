import random
print random.random()
print random.randint(1,49)

import random as r
print r.random()

from random import randint
from random import random as rand
print rand()
print randint(1,49)