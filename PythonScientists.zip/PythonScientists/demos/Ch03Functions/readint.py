def read_int() :
    line = raw_input("Enter an integer? ")
    return int(line)

n = read_int()
while n > 0:
    print n
    n = read_int()

