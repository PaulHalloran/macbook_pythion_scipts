BOTTOM = 5

def ping(depth):
    if depth >= BOTTOM: return
    print "ping",
    pong(depth+1)

def pong(depth):
    print "pong ",
    if depth % 2 == 0:
        ping(depth+1)
    else:
        pong(depth+1)

ping(0)
print

