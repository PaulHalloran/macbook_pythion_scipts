
def read_number(lo,hi):
    while True:
        line = ""
        while not line.isdigit():
            line = raw_input("Enter an integer between "+str(lo)+" and "+str(hi)+"? ")
        n = int(line)
        if (lo <= n and n <= hi):
            return n
    
x = read_number(3,6)