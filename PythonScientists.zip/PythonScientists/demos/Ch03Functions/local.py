
def func():
    x = 10
    y = 20 * g
    print "in func() x =",x,"y =",y
    
def incx():
    global x
    x += 1
    
x = 1
g = 2
func()
print "main x =",x
incx()
print "main x =",x


