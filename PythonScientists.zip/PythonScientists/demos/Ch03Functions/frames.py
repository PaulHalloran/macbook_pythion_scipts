def strato (level):
    var = level+1
    print "strato var=%d base=%d" % (var,base)
    return var


def tropo (level):
    var = level+1
    print "tropo var=%d base=%d" % (var,base)
    return strato(var)

var = 0
base = 0
tropo(var)
print "final var=%d base=%d" % (var,base)

def a():
    def b():
        print 'b'
    print 'a'
    b()
a()