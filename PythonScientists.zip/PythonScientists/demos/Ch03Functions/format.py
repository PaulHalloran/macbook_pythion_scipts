def print_width (s, n):
    print "%*s" % (n,s)
    
print_width("hello", 40)

def print_n (n, dec=4, width=10):
    print "%*.*f" % (width,dec,n)

print_n(3.14159, 6, 20)    
print_n(3.14159, 6)    
print_n(3.14159)    


print_n(width=5, dec=2, n=3.14159)
print_n(3.14159, width=5, dec=2)

