ef print_block (s, rows=3, cols=10):
    while rows > 0:
        print s*cols
        rows -= 1

print_block("*", 2, 5)
print_block("*", cols=5, rows=2)
print_block("*", cols=5)
print_block("*")
print_block(cols=5, s="*")
