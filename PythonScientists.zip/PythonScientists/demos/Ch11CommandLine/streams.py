import sys

print >>sys.stdout, "Standard out"

print >>sys.stderr, "Standard error"

sys.stderr.write("More standard output")
sys.stderr.write("%s %i\n"%("The answer is",42))

exit(1)


