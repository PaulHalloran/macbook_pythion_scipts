import os, os.path, sys
import atexit

tmpfile1 = r"file1.tmp"
tmpfile2 = r"file2.tmp"

def cleantmp1():
    try:
        if os.path.isfile(tmpfile1):
            print "Removing",tmpfile1
            os.remove(tmpfile1)
    except:
        print >>sys.stderr, "Failed to remove", tmpfile1

def cleanfile(filename):
    try:
        if os.path.isfile(filename):
            print "Removing",filename
            os.remove(filename)
    except:
        print >>sys.stderr, "Failed to remove", filename

atexit.register(cleantmp1)
atexit.register(cleanfile,tmpfile2)

with open(tmpfile1,"w") as t1:
    with open(tmpfile2,"w") as t2:
        print "Directory listing:"
        files = os.listdir(".")
        for filename in files:
            print filename
    
        