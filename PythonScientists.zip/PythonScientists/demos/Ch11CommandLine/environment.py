import os

for key,value in os.environ.items():
    print "%s=%s"%(key,value)

print os.environ["PATH"]
print os.getenv("PATH")

os.environ["EDITOR"] = "vim"

