'''
Usage: more.py [-l | --numbered] [-n lines | --count=lines] [-h | --help] files...
  Displays files one page at a time.
'''
import sys, getopt, os

class Options:
    n = 20
    numbered = False

def pager(source, opts):
    try:
        with open(source,"r") as inp:
            count = 0
            for line in inp:
                count += 1
                if opts.numbered: print "%3i "%count,
                print line,
                if count % opts.n == 0: raw_input("more...")
    except (EOFError,KeyboardInterrupt):
        pass

def usage():
    return __doc__
    
def parse(argv):
    try:
        opts = Options()
        (optionTuple, filenames) = getopt.getopt(argv[1:], "hln:", 
                                   ["help","numbered","count="])
        for (letter, value) in optionTuple:
            if letter in ("-l","--numbered"):
                opts.numbered = True
            elif letter in ("-n","--count"):
                if not value.isdigit():
                    raise UserWarning("line count "+value+" is not a valid integer")
                opts.n = int(value)
            elif letter in ("-h", "--help"):
                print usage()
                sys.exit(1)
            else:
                raise UserWarning("unhandled option "+letter)
        if not filenames:
            raise UserWarning("No filenames given")
        return (filenames,opts)
    except getopt.GetoptError as err:
        raise UserWarning(err)

#sys.argv.extend(["--count=5","more.py"])         
if __name__ == '__main__':
    try:
        (filenames, options) = parse(sys.argv)
        for filename in filenames:
            try:
                pager(filename,options)
            except IOError as err:
                print >>sys.stderr,str(err)  
    except UserWarning as err:
        print >>sys.stderr,str(err)
        print >>sys.stderr,usage()
        sys.exit(1)
    