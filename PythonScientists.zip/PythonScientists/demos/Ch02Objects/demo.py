a = 1
b = a
a = 2
print a,b

n = int(raw_input("Enter a number? "))
print "even" if n%2==0 else "odd"

count = 0
line = raw_input("Enter data lines, blank to stop? ")
while line != "":
    count += 1
    line = raw_input ("Next line? ")
print "You entered",count,"line"+("s" if count!=1 else "")