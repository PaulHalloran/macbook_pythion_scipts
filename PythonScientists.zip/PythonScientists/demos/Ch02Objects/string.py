ans = raw_input("Enter a positive integer? ")
ans = ans.strip()
if ans.isdigit():
    print "You entered a positive integer"
else:
    print "That wasn't a positive integer"
