i = 0
while i < 10:
    print i,
    i = i + 1
print

fac = 1
i = 1
while i <= 5:
    fac *= i
    i = i + 1
print "factorial 5 =",fac

data = "test how many t's in this string"
count = 0
found = 0
while found != -1:
    found = data.find("t",found)
    if found != -1:
        count += 1
        found += 1
print "found",count,"t's"
print "found",data.count("t"),"t's"