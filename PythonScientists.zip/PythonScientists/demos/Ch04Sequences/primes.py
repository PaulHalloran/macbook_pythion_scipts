for n in range(1,100):
    count = n / 2
    while count > 1:
        if n % count == 0:
            break
        count -= 1
    else:
        print n,
print