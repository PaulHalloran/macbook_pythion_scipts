words = ("The","quick","brown","fox","jumps","over","a","lazy","dog")
print " ".join(words)

sentence = "The quick brown fox jumps over a lazy dog"
print ",".join(sentence.split())

fib = (0, 1, 1, 2, 3, 5, 8, 13, 21)
# print " ".join(fib)
print " ".join([str(n) for n in fib])
print [w.lower() for w in words]
