answer = 42
pi = 3.14159
hi = "hello"

print "ans=%i" % answer
print "pi=%8.5f or %.2f" % (pi,pi)
print "%s %s" % (hi, "world")

