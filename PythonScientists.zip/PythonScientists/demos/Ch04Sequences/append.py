tuple = ()
list = []

orig_t = tuple
orig_l = list

for n in range(3):
    tuple += (n,)
    list += [n]
    print "tuple",orig_t,"->",tuple
    print "list",orig_l,"->",list