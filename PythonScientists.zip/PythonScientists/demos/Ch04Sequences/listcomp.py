numbers = (1,2,3,4,5,6,7,8,9,10)

print ",".join([str(n) for n in numbers])
print [n*n for n in numbers]
print [n for n in numbers if n%2==1]

def ask(s):
    ans = raw_input ("keep "+str(s)+"[y/n]? ")
    return ans.startswith("y") 

print [s for s in (1,2,3,5,7,11,13,17) if ask(s)]

from random import randint
numbers = [randint(1,99) for x in range(1,10)]
print numbers
