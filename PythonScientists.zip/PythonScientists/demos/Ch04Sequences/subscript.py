str = "Hello World"
print str[0]
print str[-1]

lst = [1,2,3,4,5]
lst[0] = 6
lst[-1] = 7
lst.append(8)
print lst


hello = str[0:5]
hell = str[:4]
orld = str[7:]

print hello
print hell
print orld

msg = ["the","inquisition"]
print msg
msg[0] = "The"
print msg
msg[0] = ["The","Spanish"]
print msg
msg[0:1] = ["No", "one", "expects", "any"]
print msg
msg[3:3] = ["the","Spanish"]
print msg
msg[5:6] = []
print msg

fib = (0, 1, 1, 2, 3, 5, 8, 13, 21)

for i in range(0,len(fib)):
    el = fib[i]
    print el
    
for i in range(len(fib)):print fib[i]

sudoku = [ [1,2,3], [4,5,6], [7,8,9] ]
nums = sudoku[1]
nums.reverse()
sudoku[2][1] = 99

print sudoku

phrase = "The quick brown fox jumps over the lazy dog"
quick = phrase[4:9]
The = phrase[:3]
lazy_dog = phrase[-8:]

qcbwf = phrase[4:19:3]
Teqikbonfxjmsoe_h_aydg = phrase[::2]
print qcbwf
print Teqikbonfxjmsoe_h_aydg

