fib = [0, 1, 1, 2, 3, 5, 8, 13, 21]
empty = []
one = [1]
mixed = [ 1, 1.0, "one"]
sudoku = [ [1,2,3], [4,5,6], [7,8,9] ]

numbers = [1,2,3]
print numbers
numbers.extend([4,5,6])
print numbers
numbers.append([4,5,6])
print numbers

fib = (0, 1, 1, 2, 3, 5, 8, 13, 21)
for n in fib:
    print n

colours = ('red','orange','yellow','green','blue','indigo','violet')
for i, colour in enumerate(colours):
    print i,colour
    
