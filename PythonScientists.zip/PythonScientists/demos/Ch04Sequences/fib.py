fib = (0, 1, 1, 2, 3, 5, 8, 13, 21)
for n in fib:
    print n
for i in range(0,len(fib)):
    print fib[i]

fib = (0, 1)
while len(fib) < 10:
    fib += (fib[-2]+fib[-1],)
print fib


fib = (0, 1)
while True:
    next = fib[-2]+fib[-1]
    if next > 99:
        break  
    fib += (next,)
print fib

