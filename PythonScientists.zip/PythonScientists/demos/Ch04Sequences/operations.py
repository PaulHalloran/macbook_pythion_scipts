s = "12345" + "67890"
print "len s",len(s)
if "7" in s:
    print "found 7"
hawaii = "o" * 5
if hawaii == "ooooo":
    print "Book 'em Danno"

tup = (1,2,3,4,5)+(6,7,8,9,0)
print "len tup",len(tup)
if 7 in tup:
    print "found 7"
hawaii = ("o",) * 5
if hawaii == ("o","o","o","o","o"):
    print "Book 'em Danno"

lst = [1,2,3,4,5]+[6,7,8,9,0]
print "len list",len(lst)
if 7 in lst:
    print "found 7"
hawaii = ["o"] * 5
if hawaii == ["o","o","o","o","o"]:
    print "Book 'em Danno"

data = str(lst)
print data
data = tuple(lst)
print data
data = list(tup)
print data

print [c for c in s]
print [e for e in tup]
print [str(e) for e in lst]