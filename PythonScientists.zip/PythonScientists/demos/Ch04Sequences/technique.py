values = [1,-4,56,32,2,-9,88]
print [ n if n >=0 else 0 for n in values]

values = [1,-4,56,32,2,-9,88]
print [ n for n in values if n >= 0 ]

orig = range(10)
ref = orig
clone = orig[:]
orig[0] = 100

print "Orig = ",orig
print "Ref = ",ref
print "Copy = ",clone
