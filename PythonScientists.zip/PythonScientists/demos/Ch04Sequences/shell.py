while True:
    line = raw_input("command> ")
    line = line.strip()
    if not line: 
        continue
    elif line.startswith("#"):
        continue
    elif line == "pass":
        continue
    elif line == "exit":
        break
    print line
