from random import randrange

data = r"data.txt"
with open(data,"w") as outp:
    for line in range(10):
        for block in range(5):
            outp.write ("%04i "%randrange(10000))
        outp.write ("\n")

with open(data,"r") as inp:
    for line in inp:
        print "%2i: %s"%(len(line),line),
