source = r"caesar.txt"
try:
    with open(source,"r") as inp:
        count = 0
        for line in inp:
            count += 1
            print "%3i %s"%(count,line),
            if count % 20 == 0: raw_input("more...")
except IOError:
    print "Could not find data file:"
except (EOFError,KeyboardInterrupt):
    print "\nUser aborted the listing"
