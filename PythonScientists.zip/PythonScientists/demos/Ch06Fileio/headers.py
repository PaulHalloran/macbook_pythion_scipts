data = "038270-plymouth-ave-temp.txt"
  
HDRS=21    
with open(data) as mt:
    for n in xrange(HDRS):
        mt.readline()
    print mt.readline()
              
with open(data) as mt:
    n = 0
    line = ""
    while not line.startswith("Obs"):
        line = mt.readline()
        n += 1
    print "Found headers at line",n

with open(data) as mt:
    n = 0
    for line in mt:
        n += 1
        if line.startswith("Obs:"):
            break
    print "Found headers at line",n
    