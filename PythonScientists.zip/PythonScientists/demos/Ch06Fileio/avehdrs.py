infile = "038270-plymouth-ave-temp.txt"

NAME="Name="; START="Start year="; END="End year="
with open(infile) as fp:
    for line in fp:
        if line.find(NAME)==0:
            name = line[len(NAME):].strip()
        elif line.find(START)==0:
            start = line[len(START):].strip()
        elif line.find(END)==0:
            end = line[len(END):].strip()

print "Ave Temperatures: %s %s-%s"%(name,start,end)
    