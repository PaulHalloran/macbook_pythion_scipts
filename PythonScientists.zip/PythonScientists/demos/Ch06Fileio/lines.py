source = r"caesar.txt"
try:
    with open(source,"r") as inp:
        lines = inp.readlines()
        print "There are",len(lines),"lines"
        inp.seek(0)
        line1 = inp.readline()
        line2 = inp.readline()
        print "line 1:",line1,
        print "line 2:",line2,
except Exception as cause :
    print "Error processing file",source,cause
