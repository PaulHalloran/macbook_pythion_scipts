
fftemps = "   5.2   5.0   5.4  13.6  13.5  16.7  18.4  17.2  18.6  12.8   8.2   7.3"
WIDTH = 6
data = []
start = 0
for end in xrange(WIDTH,13*WIDTH,WIDTH):
    data.append(float(fftemps[start:end]))
    start = end
print data

data = [float(t) for t in fftemps.split()]
print data

months = "Jan,Feb,Mar,Apr,May,Jun,Jul,Aug,Sep,Oct,Nov,Dec"
hdrs = [m.strip() for m in months.split(",")]

data = [5.2,5.0,5.4,13.6,13.5,16.7,18.4,17.2,18.6,12.8,8.2,7.3]

print "%6.1f"*12 % tuple(data)

print "".join ("%6.1f"%t for t in data)

print ",".join(str(f) for f in data)