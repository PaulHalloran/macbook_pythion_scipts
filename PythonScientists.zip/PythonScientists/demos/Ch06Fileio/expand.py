import os.path as FILENAME

print FILENAME.expandvars("$HOME/Desktop")
print FILENAME.expandvars("${TMPDIR}/$LOGNAME")
print FILENAME.expanduser("~ ~root")

import glob

print sorted(glob.glob("*.py"))
for name in glob.iglob("l*.py"):
    print name


