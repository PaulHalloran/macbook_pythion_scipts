import os, time
import os.path as FILENAME

print "Current dir",os.getcwd()
for name in os.listdir("."):
    filename = FILENAME.join(".",name)
    typechar = "/" if FILENAME.isdir(filename) else ""
    mtime = time.ctime(FILENAME.getmtime(filename))
    print "%-20s %s"% (name+typechar,mtime)
    if len(name)>4 and name[-4:]==".tmp":
        print "deleting ",name
        os.remove(filename)
