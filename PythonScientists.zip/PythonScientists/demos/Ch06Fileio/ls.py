import os

print os.getcwd()
for filename in os.listdir("."):
    print filename