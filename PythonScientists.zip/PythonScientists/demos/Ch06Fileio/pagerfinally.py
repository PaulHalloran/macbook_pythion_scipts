source = r"caesar.txt"
inp = None
try:
    inp = open(source,"r")
    count = 0
    for line in inp:
        count += 1
        print "%3i %s"%(count,line),
        if count % 20 == 0: raw_input("more...")
except IOError:
    print "Could not find data file:",source
except (EOFError,KeyboardInterrupt):
    print "\nUser aborted the listing"
finally:
    if inp: inp.close()
