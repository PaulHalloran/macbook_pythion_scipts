double = lambda x: x+x
print double(21)

map = {
    "+":lambda a,b:a+b,
    "-":lambda a,b:a-b,
    "*":lambda a,b:a*b,
    "/":lambda a,b:a/b
}

def apply(expr):
    (a,op,b) = expr.split()
    f = map[op]
    return f(int(a),int(b))
print apply("8 + 8")

