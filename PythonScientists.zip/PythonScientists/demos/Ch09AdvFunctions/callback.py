infile = "038270-plymouth-ave-temp.txt"

def process (fp, callback):
    while not fp.readline().startswith("Obs:"):
        pass
    data = {}
    for line in fp:
        fields = line.strip().split()
        if len(fields)!=13 or "-99.0" in fields:
            continue
        temps = [float(n) for n in fields[1:]]
        data[int(fields[0])] = callback(temps)
    return data

def avg (temps):
    return sum(temps)/len(temps)

with open(infile) as fp:
    results = process(fp,avg)
for year in sorted(results):
    print "%4i: avg %.4f" % (year,results[year])
    
with open(infile) as fp:
    results = process(fp,lambda temps: max(temps))
for year in sorted(results):
    print "%4i: max %.4f" % (year,results[year])