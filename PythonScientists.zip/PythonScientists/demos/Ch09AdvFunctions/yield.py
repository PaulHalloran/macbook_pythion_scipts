from random import randint

def odd1():
    yield 1
    yield 3
    yield 5
    yield 7  

for n in odd1():
    print n,
print

def fibonacci(n):
    last = 0
    next = 1
    for i in xrange(n):
        yield last
        (last, next) = (next, last+next)

for fib in fibonacci(10):
    print fib,
print
