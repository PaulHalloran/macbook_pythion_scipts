
import sys

def print3(*args, **options):
    out = sys.stdout
    sep = " "
    end = "\n"
    if "file" in options:
        out = options["file"]
    if "sep" in options:
        sep = options["sep"]
    if "end" in options:
        end = options["end"]
    for (i,arg) in enumerate(args): 
        if i: out.write(sep)
        out.write(arg)
    out.write(end)
        
print3 ("Hello","world",file=sys.stderr,end="")
print >>sys.stderr

def print3(*args, **options):
    prefs = dict(file=sys.stdout, sep=" ", end="\n")
    for key in options:
        if not key in prefs:
            raise NameError("Invalid print3 keyword argument: "+key)
    prefs.update(options)   
    out = prefs["file"]
    for i,arg in enumerate(args): 
        if i: out.write(prefs["sep"])
        out.write(arg)
    out.write(prefs["end"])
        
print3 ("Hello","world",file=sys.stderr,end="")
print  >>sys.stderr

def format(msg, file=sys.stdout, title=False, end="\n"):
    file.write(msg.title() if title else msg)
    file.write(end)

def quoted(msg,**kwargs):
    format("'"+msg+"'", **kwargs)
        
quoted ("hello world",file=sys.stderr,title=True)

def wrapper(*args, **kwargs):
    print3 (*args, **kwargs)

wrapper("hello","world",sep="...")
