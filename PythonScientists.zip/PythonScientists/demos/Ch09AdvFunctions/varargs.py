
def printf(formats, *args):
    print formats%args  
printf("%i + %i = %i",2,2,4)

def adder(*values):
    total = 0
    for n in values:
        total += n
    return total

print adder (1,2,3,4,5,6)


