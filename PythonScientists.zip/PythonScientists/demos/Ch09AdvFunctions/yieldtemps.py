infile = "038270-plymouth-ave-temp.txt"

def select (fp, years):
    while not fp.readline().startswith("Obs:"):
        pass
    for line in fp:
        fields = line.strip().split()       
        if len(fields)!=13 or "-99.0" in fields:
            continue
        year = int(fields[0])
        if year in years:
            yield (year,[float(n) for n in fields[1:]])

with open(infile) as fp:
    for year,temps in select(fp,range(1980,1990)):
        print "%4i: max %.4f" % (year,max(temps))
