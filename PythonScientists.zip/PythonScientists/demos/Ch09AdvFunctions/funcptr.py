read = raw_input
name = read("What is your name?")
print name

def add(a,b): return a+b
def sub(a,b): return a-b
def mul(a,b): return a*b
def div(a,b): return a/b

def apply1(expr):
    (a,op,b) = expr.split()
    f = None
    if op=="+":
        f = add
    elif op=="-":
        f = sub
    elif op=="*":
        f = mul
    elif op=="/":
        f = div
    return f(int(a),int(b))
print apply1("2 + 2")

map = {"+":add,"-":sub,"*":mul,"/":div}
def apply2(expr):
    (a,op,b) = expr.split()
    f = map[op]
    return f(int(a),int(b))
print apply2("4 + 4")
