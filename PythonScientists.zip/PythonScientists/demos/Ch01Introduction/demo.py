answer = 42
pi = 3.14159
hi = "hello"

print hi,answer

