name = raw_input("What is your name? ")
if len(name) == 0:
    name = "anonymous"
print "Hello "+name
    
unknown = False
if name == "anonymous":
    print "What a strange name"
    unknown = True
if not unknown: print "Welcome"

x = int(raw_input("Think of a number between 1 and 10? "))
if x < 1:
    print "too small"
elif x > 10:
    print "too big"
else:
    print "just right"

