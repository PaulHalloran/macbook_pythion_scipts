'''
Useful functions for paging files

@author: Martin Bond
'''
def more(source, n=20):
    '''
    Display a file n lines at a time
    
    source -- filename
    n -- number of lines to show (default 20)
    
    returns -- None
    '''
    try:
        with open(source,"r") as inp:
            count = 0
            for line in inp:
                count += 1
                print "%3i %s"%(count,line),
                if count % n == 0: 
                    raw_input("more...")
    except EOFError:
        pass

if __name__ == "__main__":
    more("pager.py")