
import sys
print "\n".join(sys.path)
#sys.path.append("./lib")
sys.path.append("./pager.zip")

import lib.fileio.pager
lib.fileio.pager.more("lib/fileio/pager.py")

from lib.fileio.pager import more
more("lib/fileio/pager.py")



