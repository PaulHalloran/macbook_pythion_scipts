def main(argv):
    for filename in argv:
        inp = None
        try:
            inp = open(filename,"r")
            for line in inp: print line,
        except Exception as err:
            print str(err)
        finally:
            if inp: inp.close()
            
if __name__ == '__main__':
    main(sys.argv[1:])