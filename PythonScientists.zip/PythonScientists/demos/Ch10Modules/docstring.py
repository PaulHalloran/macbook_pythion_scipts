import sys
sys.path.append("lib/fileio")
import pager
print pager.__doc__
print pager.more.__doc__

