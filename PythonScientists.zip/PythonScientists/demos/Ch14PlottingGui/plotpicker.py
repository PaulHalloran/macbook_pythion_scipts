import calendar
import metdata as mt
import matplotlib.pyplot as plt
from matplotlib.font_manager import FontProperties

FILE = "038270-plymouth-ave-temp.txt"

class YearPlot:
    def __init__(self,ax,temps,year=2000):
        self.ax = ax
        self.temps = temps
        canvas = ax.figure.canvas
        canvas.mpl_connect('pick_event', self.on_pick)
        ax.grid(True)
        ax.set_ylim(-1,20)
        ax.set_ylabel(r"Temperature $^o$C")
        self.x = range(1,13)
        ax.set_xlim(1,len(self.x))
        plt.xticks(self.x, calendar.month_abbr[1:13], rotation=66)
        fig.subplots_adjust(bottom=0.15)
        self.add(year)
    
    def add(self,year):
        y = self.temps.year(year)
        ax.plot(self.x, y, picker=5, label=str(year))
        ax.set_xlabel("Monthly Average Temp for %i"%year)
        ax.legend(loc='lower center')
        plt.draw()
        
    def on_pick(self,event):
        if event.artist.get_axes() != self.ax:
            return
        month = round(event.mouseevent.xdata)
        textx = 2 if month<2 else 10 if month>10 else month
        temp = event.mouseevent.ydata
        months = self.temps.month(month)
        msg = "avg %.2f\nmin %.2f\nmax %.2f" % (temp,months.min(),months.max())
        self.ax.texts[:] = []
        self.ax.text(textx, temp-2, msg, ha="left", va="top",
                fontproperties=FontProperties(weight='bold', size='large'),
                bbox=dict(edgecolor='k', facecolor='#0000FF', linewidth=3, alpha=.35))
        plt.draw()
            
if __name__ == '__main__':
    temps = mt.AvgTemp(FILE)
    fig = plt.figure()
    ax = fig.add_subplot(111)
    plot = YearPlot(ax,temps,2000)
    plt.show()

    




