import numpy as np

def keyval(line):
    tup =  line.split('=')
    if len(tup) != 2:
        raise UserWarning("Invalid key=value data: %s" % line)
    return tup[1].strip()

class MapData:
    def __init__(self,filename):
        with open(filename,"r") as ifp:
            self.nrows = int(keyval(ifp.readline()))
            self.ncols = int(keyval(ifp.readline()))
            self.cellsize = int(keyval(ifp.readline()))
            self.nodata = float(keyval(ifp.readline()))
            self.data = np.loadtxt(ifp)
        
    def __str__(self):
        return "MapData size [%i,%i], %dm cells" % (self.nrows, self.ncols, self.cellsize)
    __repr__ = __str__

    def min(self):
        return np.ma.masked_values(self.data,self.nodata).min()
    
    def max(self):
        return np.ma.masked_values(self.data,self.nodata).max()
    
    def masked(self):
        return np.ma.masked_values(self.data,self.nodata)    

