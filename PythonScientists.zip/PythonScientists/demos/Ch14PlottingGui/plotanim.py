import calendar
import time
import metdata as mt
import matplotlib.pyplot as plt

FILE = "038270-plymouth-ave-temp.txt"

class YearPlot:
    def __init__(self,ax,temps,year=2000):
        self.ax = ax
        self.temps = temps
        ax.grid(True)
        ax.set_ylim(-1,20)
        ax.set_ylabel(r"Temperature $^o$C")
        self.x = range(1,13)
        ax.set_xlim(1,len(self.x))
        plt.xticks(self.x, calendar.month_abbr[1:13], rotation=66)
        fig.subplots_adjust(bottom=0.15)
        self.add(year)

    keep = 5    
    years = []
    def add(self,year):
        if len(ax.lines) >= self.keep:
            ax.lines[0:1] = []
            self.years[0:1] = []
        self.years.append(year)
        y = self.temps.year(year)
        ax.plot(self.x, y, label=str(year))
        ax.set_xlabel("Monthly Average Temp for %s"%self.years)
        ax.legend(loc='lower center')
        plt.draw()
    
if __name__ == '__main__':
    temps = mt.AvgTemp(FILE) 
    plt.ion()
    fig = plt.figure()
    ax = fig.add_subplot(111)
    plot = YearPlot(ax,temps,temps.years[0])
    for year in temps.years[1:]:
        plot.add(year)
        time.sleep(0.1)


    




