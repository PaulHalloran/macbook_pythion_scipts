import sys
import numpy as np
import matplotlib.pyplot as plt
from mpl_toolkits.basemap import Basemap

FILE = "uk-map-data.txt"

def keyval(line):
    tup =  line.split('=')
    if len(tup) != 2:
        raise UserWarning("Invalid key=value data: %s" % line)
    return tup[1].strip()

class MapData:
    def __init__(self,filename):
        with open(filename,"r") as ifp:
            self.nrows = int(keyval(ifp.readline()))
            self.ncols = int(keyval(ifp.readline()))
            self.cellsize = int(keyval(ifp.readline()))
            self.nodata = float(keyval(ifp.readline()))
            self.data = np.loadtxt(ifp)
        
    def __str__(self):
        return "MapData size [%i,%i], %im cells" % (self.nrows, self.ncols, self.cellsize)
    __repr__ = __str__

    def min(self):
        return np.ma.masked_values(self.data,self.nodata).min()
    
    def max(self):
        return np.ma.masked_values(self.data,self.nodata).max()
    
    def masked(self):
        return np.ma.masked_values(self.data,self.nodata)    

def plot_ukmap(ax,mapdata):
    def iround(value,step,down=True):
        rounded = (value // step) * step
        return rounded if down else rounded + step
    
    bmap = Basemap(ax=ax, 
                   resolution='i',projection='tmerc',
                   lon_0=-2.0,lat_0=49.0,
                   rsphere=[6377563.396, 6356256.909],
                   llcrnrlon=-10.1, llcrnrlat=47.8, urcrnrlon=3.55, urcrnrlat=61.0, 
                   area_thresh=1., fix_aspect=False)
    bmap.drawcoastlines()
    bmap.drawparallels(np.arange(48.,61.,2.))
    bmap.drawmeridians(np.arange(-12.,4.,2.))
    (lons, lats) = bmap.makegrid(mapdata.ncols,mapdata.nrows)
    (x, y) = bmap(lons,lats)
    lo = iround(mapdata.min(),10)
    hi = iround(mapdata.max(),10,False)
    levels = np.linspace(lo,hi,17).round()
    cs = bmap.contourf(x, y, mapdata.masked(), levels=levels)
    ax.text(0.1, 0.9, "%im cells"%mapdata.cellsize, transform=ax.transAxes, 
            backgroundcolor="#dddddd", weight="bold")
    cbar = plt.colorbar(cs)
    plt.title("Map data clipped to UK coastline")
    plt.show()    

if __name__ == "__main__":
    mapdata = MapData(FILE)
    ax = plt.figure().add_subplot(111)
    plot_ukmap(ax,mapdata)

