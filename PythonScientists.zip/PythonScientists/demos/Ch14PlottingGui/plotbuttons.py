import calendar
import metdata as mt
import matplotlib.pyplot as plt
import matplotlib.widgets as widgets

FILE = "038270-plymouth-ave-temp.txt"
YEAR = 1900

class YearPlot:
    def __init__(self,ax,temps,year=2000):
        self.ax = ax
        self.temps = temps
        ax.grid(True)
        ax.set_ylim(-1,20)
        ax.set_ylabel(r"Temperature $^o$C")
        self.x = range(1,13)
        ax.set_xlim(1,len(self.x))
        plt.xticks(self.x, calendar.month_abbr[1:13], rotation=66)
        fig.subplots_adjust(bottom=0.15)
        self.add(year)
    
    def add(self,year):
        ax.lines[:] = []
        y = self.temps.year(year)
        ax.plot(self.x, y, label=str(year))
        ax.set_xlabel("Monthly Average Temp for %i"%year)
        ax.legend(loc='lower center')
        plt.draw()

class NavButtons:
    def __init__(self,plot,temps,index):
        self.plot = plot
        self.index = index
        self.temps = temps
        plt.subplots_adjust(right=0.85)
        self.butnext = widgets.Button(plt.axes([0.875, 0.85, 0.1, 0.05]), 'Next')
        self.butnext.on_clicked(self.next)
        self.butprev = widgets.Button(plt.axes([0.875, 0.79, 0.1, 0.05]), 'Previous')
        self.butprev.on_clicked(self.prev)

    def next(self, event):
        if self.index < len(temps.years)-1:
            self.index += 1
            self.plot.add(temps.years[self.index])

    def prev(self, event):
        if self.index > 0:
            self.index -= 1
            self.plot.add(temps.years[self.index])
    
if __name__ == '__main__':
    temps = mt.AvgTemp(FILE)
    start = temps.years.index(YEAR)
    fig = plt.figure()
    ax = fig.add_subplot(111)
    plot = YearPlot(ax,temps,YEAR)
    nav = NavButtons(plot,temps,start)
    plt.show()

    




