
import numpy as np
from mapdata import MapData
import matplotlib.pyplot as plt

def contours(mapdata):
    ax = plt.figure().add_subplot(111)
    cs = ax.contour(mapdata.masked())
    cbar = plt.colorbar(cs)
    plt.title("Contour data clipped to UK coastline")
    plt.show()  
      
def filled(mapdata):
    ax = plt.figure().add_subplot(111)
    cs = ax.contourf(mapdata.masked())
    cbar = plt.colorbar(cs)
    plt.title("Filled contour data clipped to UK coastline")
    plt.show() 
     
def levels(mapdata):
    ax = plt.figure().add_subplot(111)
    levels = np.linspace(mapdata.min()/10*10,(mapdata.max()/10+1)*10,17).round()
    cs = ax.contourf(mapdata.masked(),levels=levels,cmap=plt.hot())
    cbar = plt.colorbar(cs)
    plt.title("Filled contour data clipped to UK coastline")
    plt.show()  
      
def image(mapdata):
    ax = plt.figure().add_subplot(111)
    cs = ax.imshow(mapdata.masked(),origin='lower',aspect='auto')
    cbar = plt.colorbar(cs)
    plt.title("Image data clipped to UK coastline")
    plt.show()    
                

FILE = "uk-map-data.txt"
mapdata = MapData(FILE)
contours(mapdata)
filled(mapdata)
levels(mapdata)
image(mapdata)


