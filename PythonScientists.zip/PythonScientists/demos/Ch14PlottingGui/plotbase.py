import calendar
import time
import metdata as mt
import matplotlib.pyplot as plt

FILE = "038270-plymouth-ave-temp.txt"

class YearPlot:
    def __init__(self,ax,temps,year=2000):
        self.ax = ax
        self.temps = temps
        ax.grid(True)
        ax.set_ylim(-1,20)
        ax.set_ylabel(r"Temperature $^o$C")
        self.x = range(1,13)
        ax.set_xlim(1,len(self.x))
        plt.xticks(self.x, calendar.month_abbr[1:13], rotation=66)
        fig.subplots_adjust(bottom=0.15)
        self.add(year)

    def add(self,year):
        y = self.temps.year(year)
        ax.plot(self.x, y, label=str(year))
        ax.set_xlabel("Monthly Average Temp for %s"%year)
        ax.legend(loc='lower center')
        plt.draw()
    
if __name__ == '__main__':
    temps = mt.AvgTemp(FILE) 
    fig = plt.figure()
    ax = fig.add_subplot(111)
    yearPlot = YearPlot(ax,temps,2000)
    yearPlot.add(1990)
    yearPlot.add(1980)
    plt.show()

