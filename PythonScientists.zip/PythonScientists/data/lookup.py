import sys, re
WORDS = "words.txt"

def found(line,pattern):
    return re.search(pattern,line,re.IGNORECASE)
                   
def main(pattern):
    inp = None
    try:
        print "PATTERN:",pattern 
        inp = open(WORDS,"r")
        count = 0
        for line in inp:
            if found(line,pattern):
                print line,
                count += 1
                if (count >= 20):
                    ans = raw_input("More...")
                    if re.search(r"^\s*[qQ]",ans):break
                    count = 0
    except (EOFError,KeyboardInterrupt):
        pass
    finally:
        if inp: inp.close()

if __name__ == "__main__":
    if (len(sys.argv) > 1):
        for pattern in sys.argv[1:]:
            main(pattern)
    else:
        main(r"^.*$")
