import numpy as np

infile = r"yeoviltondata.txt"
HDRS=6
# Z index
MAXT=0
MINT=1
RAIN=2
      
def read(filename):
    data = {}
    with open(filename,"r") as inp:
        for line in range(0,HDRS):
            inp.readline()
        for line in inp:
            values = line.split()
            if len(values) != 6:
                continue
            year = int(values[0])
            month = int(values[1])
            maxt = float(values[2])
            mint = float(values[3])
            rain = float(values[5])
            if year not in data:
                data[year] = [None]*13
            data[year][month] = np.array([maxt, mint, rain])
    loyear = min(data.keys())
    hiyear = max(data.keys())
    print data.keys()
    readings = np.empty([hiyear-loyear+1,13,3],dtype=np.float)
    for y in data:
        for m in xrange(0,13):
            readings[y-loyear,m,:] = data[y][m]
    return (loyear,hiyear,readings)
    
try:
    (loyear,hiyear,readings) = read(infile)
    print "data for 1976\n",readings[1976-loyear][1:]
    
    print "average monthly rainfall",readings[:,1:,RAIN].mean(axis=0)
    print "average July rainfall",readings[:,7,RAIN].mean()
    print "maximum temperature in 1976",readings[1976-loyear,1:,MAXT].max()
    
except IOError:
    print "Cannot find filename",infile

