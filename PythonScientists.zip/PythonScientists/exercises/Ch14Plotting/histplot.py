import calendar
import numpy as np
import matplotlib.pyplot as plt

infile = r"yeoviltondata.txt"
HDRS=6
# Z index
MAXT=0
MINT=1
RAIN=2
      
def read(filename):
    data = {}
    with open(filename,"r") as inp:
        for line in range(0,HDRS):
            inp.readline()
        for line in inp:
            values = line.split()
            if len(values) != 6:
                continue
            year = int(values[0])
            month = int(values[1])
            maxt = float(values[2])
            mint = float(values[3])
            rain = float(values[5])
            if year not in data:
                data[year] = [None]*13
            data[year][month] = np.array([maxt, mint, rain])
    loyear = min(data.keys())
    hiyear = max(data.keys())
    readings = np.empty([hiyear-loyear+1,13,3],dtype=np.float)
    for y in data:
        for m in xrange(0,13):
            print loyear,y,m
            readings[y-loyear,m,:] = data[y][m]
    return (loyear,hiyear,readings)

def plot_temp(loyear,hiyear,readings):
    ax = plt.figure().add_subplot(111)
    minavg = readings[:,1:,MINT].mean(axis=0)
    maxavg = readings[:,1:,MAXT].mean(axis=0)
    rainavg = readings[:,1:,RAIN].mean(axis=0)
    
    ax.plot(minavg,label="min temp",linewidth=2,color="blue") 
    ax.plot(maxavg,label="max temp",linewidth=2,color="red")
    ax.grid()
    ax.legend(loc="upper left")
    ax.set_xlabel("Monthly Averages %i-%i"%(loyear,hiyear))
    ax.set_ylabel(r"Temperature $^o$C")
    bx = ax.twinx()
    bx.plot(rainavg,label="rainfall",linestyle=":",linewidth=3,color="green")
    bx.set_ylim(0,rainavg.max()*1.1)
    bx.set_ylabel("Rainfall mm")
    bx.legend()
    plt.xticks(np.arange(12), calendar.month_abbr[1:13], rotation=66)
    plt.subplots_adjust(bottom=0.15)
    plt.show()
    
try:
    (loyear,hiyear,readings) = read(infile)   
    plot_temp(loyear,hiyear,readings)
    
except IOError:
    print "Cannot find filename",infile

