import numpy as np
import matplotlib.pyplot as plt

def genbmi(weight,height):
    x = np.arange(height[0],height[1])
    y = np.arange(weight[0],weight[1])
    bmi = np.empty([len(y),len(x)])
    for i,w in enumerate(y):
        for j,h in enumerate(x):
            bmi[i,j] = float(w)/(h*h)*10000
    return bmi

WEIGHTS = (25,116)
HEIGHTS = (136,194)
LEVELS = [0, 20, 26, 31, 41,64]
COLORS = ["blue","green","yellow","orange","red"]
LABELS = ["under\nweight","healthy","over\nweight","clinically\nobese","morbidly\nobese"]

bmi = genbmi(WEIGHTS,HEIGHTS)

plt.figure().add_subplot(111)
cs = plt.contourf(np.arange(HEIGHTS[0],HEIGHTS[1]),
                  np.arange(WEIGHTS[0],WEIGHTS[1]),
                  bmi,levels=LEVELS,colors=COLORS,alpha=0.85)
plt.xlabel("height in cm")
plt.ylabel("weight in kg")
plt.grid()
cbar = plt.colorbar(cs)
cbar.ax.set_yticklabels(LABELS,va="baseline")
plt.title("Body Mass Index")
plt.show()
