infile = r"yeoviltondata.txt"
HDRS=6
# Z index
MAXT=0
MINT=1
RAIN=2
      
def read(filename):
    data = {}
    with open(filename,"r") as inp:
        for line in range(0,HDRS):
            inp.readline()
        for line in inp:
            values = line.split()
            if len(values) != 6:
                continue
            year = int(values[0])
            month = int(values[1])
            maxt = float(values[2])
            mint = float(values[3])
            rain = float(values[5])
            if year not in data:
                data[year] = [None]*13
            data[year][month] = (maxt, mint, rain)
    return data
    
try:
    data = read(infile)
    print data[1976]
    
except IOError:
    print "Cannot find filename",filename

