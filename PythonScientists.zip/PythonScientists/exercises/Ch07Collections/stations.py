HDRS = 2
def parse(inp):
    list = {}
    for line in range(0,HDRS):
        inp.readline()
    for line in inp:
        name = line[14:54].strip()
        domain = line[54:62].strip()
        if name in list:
            list[name].append(domain)
        else:
            list[name] = [domain]
    for key in  sorted(list.keys()):
        if list[key].count("SYNOP")>0:
            print "%s:\n  %s"%(key,list[key])
            
infile = r"midas-stations.txt"
inp = None
try:
    inp = open(infile,"r")
    parse(inp)
except IOError:
    print "Cannot find file",infile
finally:
    if inp: inp.close()
