import re

def parse(filename):
    concord = {}
    with open(filename,"r") as fp:
        for line in fp:
            line = re.sub(r"[^a-zA-Z ]","",line)
            for word in line.split():
                word = word.lower()
                if word in concord:
                    concord[word] += 1
                else:
                    concord[word] = 1
    return concord

        
def showall(concord):
    print "ALL WORDS"
    for word in sorted(concord):
        print "%5i : %s"%(concord[word],word)
    print

def showfreq(concord,top=20):
    freq = {}
    for word, count in concord.items():
        if count in freq:
            freq[count].append(word)
        else:
            freq[count] = [word]
    print "FREQUENT WORDS"
    for i,count in enumerate(reversed(sorted(freq))):
        print "%5i : %s"%(count," ".join(freq[count]))
        if i >= top: break
    print

files = ("frankenstein.txt","journey-to-the-centre-of-the-earth.txt")

for filename in files:
    try:
        print filename
        print "="*len(filename)
        concord = parse(filename)
        showall(concord)
        showfreq (concord,5)
    except IOError:
        print "Cannot find filename",filename