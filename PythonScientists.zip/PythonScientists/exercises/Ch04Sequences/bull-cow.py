import random

LEN = 4
RANGE = 6
DUPLICATES = True

def todigit(ch):
    if len(ch) != 1:
        return None
    return ord(ch)-ord('0')

def plural(n):
    if n == 1:
        return ""
    return "s"

def build_code():
    code = []
    while len(code) < LEN:
        digit = random.randrange(RANGE)+1
        if DUPLICATES or not digit in code:
            code.append(digit)
    return code

def match(code,guess):
    bulls = 0
    cows = 0
    ccopy = code[:]
    gcopy = guess[:]
    for i in range(len(guess)):
        if ccopy[i] == gcopy[i]:
            bulls += 1
            ccopy[i] = gcopy[i] = None 
    for c in range(len(guess)):
        if ccopy[c]:
            for g in range(len(gcopy)):
                if ccopy[c] == gcopy[g]:
                    cows += 1
                    gcopy[g] = None
    return (bulls,cows)

code = build_code()

print "I have a secret code with %i numbers from 1 to %i."%(LEN,RANGE)

running = True
count = 0
while running:
    line = raw_input("Enter a %i digit guess or empty line to give up? "%(LEN)).strip()
    if len(line) == 0:
        running = False
    elif line.isdigit():
        guess = [todigit(ch) for ch in line]
    else:
        guess = [todigit(ch) for ch in line.split()]
    if running and len(guess) != LEN:
        print "Bad format, try again"
    elif running:
        count += 1
        (bulls, cows) = match(code,guess)
        print "guess %2i: %s %i bull%s, %i cow%s"%(count,guess,bulls,plural(bulls),cows,plural(cows))
        if bulls == LEN:
            print "Well done you found my code"
            running = False
print "The code was %s"%code   