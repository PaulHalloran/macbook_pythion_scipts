import sys, getopt, os

HDRS = 2
HEADINGS = {"t":"TYPE","n":"NUMBER","m":"NAME","d":"DOMAIN","l":"LOCATION","p":"POST-CODE"}
COLS = ((0,6),(6,14),(14,54),(54,62),(62,95),(143,152))

ALL = ("t","n","m","d","l","p")
OPT = "".join(ALL)

def parse(inp,selected):
    for line in range(0,HDRS):
        inp.readline()
    print ",".join([HEADINGS[s] for s in selected])
    for line in inp:
        fields = []
        for s in selected:
            n = ALL.index(s)
            cols = COLS[n]
            fields.append(line[cols[0]:cols[1]].strip())
        print ",".join(fields)

def convert(file,selected):            
    inp = None
    try:
        inp = open(file,"r")
        parse(inp,selected)
    except IOError:
        print "Cannot find file",file
    finally:
        if inp: inp.close()

def usage():
    print os.path.basename(sys.argv[0]),"[-"+OPT+"] files..."

def main(argv):
    try:
        (opts, args) = getopt.getopt(argv, OPT, ["help"])
        selected = []
        for opt, arg in opts:
            letter = opt[1:]
            if letter in OPT:
                if letter not in selected:
                    selected.append(letter)
            elif opt in ("--help"):
                usage()
                sys.exit(0)
            else:
                raise UserWarning("unhandled option "+opt)
        if not selected:
            selected = ALL
        if len(args) != 1:
            raise ValueError("Exactly one filename must be given")
        for filename in args:
            convert(filename,selected)
    except (getopt.GetoptError, ValueError) as err:
        print str(err)
        usage()
        sys.exit(2)
            
if __name__ == '__main__':
    if len(sys.argv) > 1:
        main(sys.argv[1:])
    else:
        main((r"midas-stations.txt",))