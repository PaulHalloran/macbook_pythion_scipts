def sieve():
    yield 1
    primes = [2,3]
    yield primes[0]
    yield primes[1]
    candidate = 5
    while True:
        for n in primes:
            if candidate % n == 0:
                break
        else:
            primes.append(candidate)
            yield candidate
        candidate += 2
        

for i,n in enumerate(sieve()):
    print n,
    if (i >= 20): break
print