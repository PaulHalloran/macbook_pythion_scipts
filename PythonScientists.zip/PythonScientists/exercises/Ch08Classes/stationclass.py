FILE = r"midas-stations.txt"
HDRS = 2

def parse(inp):
    for line in range(0,HDRS):
        inp.readline()
    for line in inp:
        typechar = line[0:6].strip()
        number = line[6:14].strip()
        name = line[14:54].strip()
        domain = line[54:62].strip()
        fields = (typechar,name,number,domain)
        print ",".join(fields)

def process(filename):            
    try:
        with open(filename,"r") as inp:
			parse(inp)
    except IOError:
        print "Cannot find filename",filename
            
if __name__ == '__main__':
     process(FILE)